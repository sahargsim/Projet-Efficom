from flask import Flask, render_template, url_for, request, redirect

app = Flask(__name__)

@app.route('/<string:page_name>')
def html_page(page_name):
    return render_template(page_name)

@app.route('/submit_form', methods=['GET', 'POST'])
def submit_form(guestname=None):
    if request.method == 'POST':
        data = request.form.to_dict()
        #send message information by e-mail
        guestname = request.form['name']
        return render_template('/submitted_form.html',name=guestname)
    else:
        return 'FAILED'

@app.route('/submit_reservation', methods=['GET', 'POST'])
def submit_reservation(name=None): 
    if request.method == 'POST':
        data = request.form.to_dict()
        # Add reservation to DB 
        name = request.form['name']
        return render_template('/reservation_ok.html',name=name)
    else:
        return 'FAILED'

#@app.route('/cart.html', methods=['GET', 'POST'])
#def cart():
#connect to data base 
#create a order
#add product and its information to the order
#filter the order that have same user
#make the total


